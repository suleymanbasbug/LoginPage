"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("@smartface/native");
require("i18n"); // Initialize i18n
var application_1 = __importDefault(require("@smartface/native/application"));
var source_map_1 = require("@smartface/source-map");
var system_1 = __importDefault(require("@smartface/native/device/system"));
// Set uncaught exception handler, all exceptions that are not caught will
// trigger onUnhandledError callback.
application_1.default.on('unhandledError', function (e) {
    var error = (0, source_map_1.errorStackBySourceMap)(e);
    var message = {
        message: system_1.default.OS === system_1.default.OSType.ANDROID ? error.message : e.message,
        stack: error.stack
    };
    console.error('Unhandled Error: ', message);
    alert(JSON.stringify(message, null, 2), e.type || 'Application Error');
});
require("start");
//# sourceMappingURL=app.js.map
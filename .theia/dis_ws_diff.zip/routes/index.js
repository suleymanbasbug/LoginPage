"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var router_1 = require("@smartface/router");
var application_1 = __importDefault(require("@smartface/native/application"));
var tabbar_1 = __importDefault(require("./tabbar"));
var auth_1 = __importDefault(require("./auth"));
application_1.default.on('backButtonPressed', function () {
    var _a;
    (_a = router_1.NativeRouter.getActiveRouter()) === null || _a === void 0 ? void 0 : _a.goBack();
});
var router = router_1.NativeRouter.of({
    path: '/',
    isRoot: true,
    routes: [tabbar_1.default, (0, auth_1.default)()]
});
exports.default = router;
//# sourceMappingURL=index.js.map
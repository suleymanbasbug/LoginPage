"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var pgLogin_1 = __importDefault(require("generated/pages/pgLogin"));
var mixins_1 = require("@smartface/mixins");
var PgLogin = /** @class */ (function (_super) {
    __extends(PgLogin, _super);
    function PgLogin(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        _this.button1.on('press', function () {
            _this.router.push('/btb');
        });
        return _this;
    }
    /**
     * @event onShow
     * This event is called when the page appears on the screen (everytime).
     */
    PgLogin.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.initBackButton(this.router); //Addes a back button to the page headerbar.
    };
    /**
     * @event onLoad
     * This event is called once when the page is created.
     */
    PgLogin.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
    };
    return PgLogin;
}((0, mixins_1.withDismissAndBackButton)(pgLogin_1.default)));
exports.default = PgLogin;
//# sourceMappingURL=pgLogin.js.map
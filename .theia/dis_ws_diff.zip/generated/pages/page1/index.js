"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//------------------------------------------------------------------------------
//
//     This code was auto generated.
//
//     Manual changes to this file may cause unexpected behavior in your application.
//     Manual changes to this file will be overwritten if the code is regenerated.
//
//------------------------------------------------------------------------------
var styling_context_1 = require("@smartface/styling-context");
var page_1 = __importDefault(require("@smartface/native/ui/page"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var button_1 = __importDefault(require("@smartface/native/ui/button"));
var $Page1 = /** @class */ (function (_super) {
    __extends($Page1, _super);
    function $Page1(props) {
        var _this = _super.call(this, Object.assign({ orientation: page_1.default.Orientation.PORTRAIT }, props)) || this;
        _this._children = {};
        _this.ios && (_this.ios.safeAreaLayoutMode = true);
        _this._children.statusBar = _this.statusBar || {};
        _this._children.headerBar = _this.headerBar || {};
        _this.addChildByName(new $FlWrapper(), 'flWrapper');
        _this.addChildByName(new $BtnNext(), 'btnNext');
        _this.flWrapper = _this.children.flWrapper;
        _this.lbl = _this.children.flWrapper.children.lbl;
        _this.btnNext = _this.children.btnNext;
        _this.applyTestIDs('_Page1');
        return _this;
    }
    Object.defineProperty($Page1.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    $Page1.prototype.getName = function () {
        return 'Page1';
    };
    $Page1.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.title = 'Page1';
    };
    $Page1.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    /**
     * @deprecated The method should not be used
     */
    $Page1.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $Page1.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Page1.prototype.removeChild = function (child) {
        var _this = this;
        _super.prototype.removeChild.call(this, child);
        Object.keys(this._children).forEach(function (name) {
            if (child === _this._children[name])
                delete _this._children[name];
        });
    };
    $Page1.prototype.removeChildren = function () {
        this._children = { statusBar: this._children.statusBar, headerBar: this._children.headerBar };
        _super.prototype.removeChildren.call(this);
    };
    $Page1.$$styleContext = {
        classNames: '.sf-page #page1',
        defaultClassNames: ' .default_page',
        userProps: {},
        statusBar: {
            classNames: '.sf-statusBar',
            defaultClassNames: ' .default_statusBar',
            userProps: {}
        },
        headerBar: {
            classNames: '.sf-headerBar',
            defaultClassNames: ' .default_headerBar',
            userProps: {}
        }
    };
    return $Page1;
}((0, styling_context_1.styleablePageMixin)(page_1.default)));
exports.default = $Page1;
var $FlWrapper = /** @class */ (function (_super) {
    __extends($FlWrapper, _super);
    function $FlWrapper(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $FlWrapper$$Lbl(), 'lbl');
        return _this;
    }
    Object.defineProperty($FlWrapper.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $FlWrapper.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $FlWrapper.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $FlWrapper.$$styleContext = {
        classNames: '.sf-flexLayout #page1-wrapper',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $FlWrapper;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $FlWrapper$$Lbl = /** @class */ (function (_super) {
    __extends($FlWrapper$$Lbl, _super);
    function $FlWrapper$$Lbl(props) {
        return _super.call(this, { text: 'Page1' }) || this;
    }
    $FlWrapper$$Lbl.$$styleContext = {
        classNames: '.sf-label #page1-lbl',
        defaultClassNames: '.default_common .default_label',
        userProps: { usePageVariable: true }
    };
    return $FlWrapper$$Lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $BtnNext = /** @class */ (function (_super) {
    __extends($BtnNext, _super);
    function $BtnNext(props) {
        return _super.call(this, { text: 'Next Page' }) || this;
    }
    $BtnNext.$$styleContext = {
        classNames: '.sf-button #page1-btnNext',
        defaultClassNames: '.default_common .default_button',
        userProps: { usePageVariable: true }
    };
    return $BtnNext;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
//# sourceMappingURL=index.js.map
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var styling_context_1 = require("@smartface/styling-context");
var listviewitem_1 = __importDefault(require("@smartface/native/ui/listviewitem"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var $Simple_listviewItem = /** @class */ (function (_super) {
    __extends($Simple_listviewItem, _super);
    function $Simple_listviewItem(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $Simple_listviewItem$$LblTitle(), 'lblTitle');
        _this.addChildByName(new $Simple_listviewItem$$LblChevron(), 'lblChevron');
        _this.addChildByName(new $Simple_listviewItem$$FlLine(), 'flLine');
        _this.lblTitle = _this.children.lblTitle;
        _this.lblChevron = _this.children.lblChevron;
        _this.flLine = _this.children.flLine;
        _this.testId = '___library___Simple_listviewItem';
        return _this;
    }
    Object.defineProperty($Simple_listviewItem.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $Simple_listviewItem.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $Simple_listviewItem.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            _super.prototype.addChild.call(this, child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    $Simple_listviewItem.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Simple_listviewItem.$$styleContext = {
        classNames: '.sf-listViewItem .simple-listviewItem',
        defaultClassNames: '.default_common .default_listViewItem',
        userProps: { width: null, height: null }
    };
    return $Simple_listviewItem;
}((0, styling_context_1.styleableContainerComponentMixin)(listviewitem_1.default)));
exports.default = $Simple_listviewItem;
var $Simple_listviewItem$$LblTitle = /** @class */ (function (_super) {
    __extends($Simple_listviewItem$$LblTitle, _super);
    function $Simple_listviewItem$$LblTitle(props) {
        var _this = _super.call(this, { text: 'ListView Cell Title' }) || this;
        _this.testId = '___library___Simple_listviewItem_LblTitle';
        return _this;
    }
    $Simple_listviewItem$$LblTitle.$$styleContext = {
        classNames: '.sf-label .simple-listviewItem-title',
        defaultClassNames: '.default_common .default_label',
        userProps: { marginLeft: 16 }
    };
    return $Simple_listviewItem$$LblTitle;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $Simple_listviewItem$$LblChevron = /** @class */ (function (_super) {
    __extends($Simple_listviewItem$$LblChevron, _super);
    function $Simple_listviewItem$$LblChevron(props) {
        var _this = _super.call(this, { text: '' }) || this;
        _this.testId = '___library___Simple_listviewItem_LblChevron';
        return _this;
    }
    $Simple_listviewItem$$LblChevron.$$styleContext = {
        classNames: '.sf-label .simple-listviewItem-chevron',
        defaultClassNames: '.default_common .default_label',
        userProps: { marginRight: 16 }
    };
    return $Simple_listviewItem$$LblChevron;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $Simple_listviewItem$$FlLine = /** @class */ (function (_super) {
    __extends($Simple_listviewItem$$FlLine, _super);
    function $Simple_listviewItem$$FlLine(props) {
        var _this = _super.call(this, props) || this;
        _this.testId = '___library___Simple_listviewItem_FlLine';
        return _this;
    }
    $Simple_listviewItem$$FlLine.$$styleContext = {
        classNames: '.sf-flexLayout .simple-listviewItem-line .simple-listviewItem-simple-chevron',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $Simple_listviewItem$$FlLine;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
//# sourceMappingURL=Simple_listviewItem.js.map
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//------------------------------------------------------------------------------
//
//     This code was auto generated.
//
//     Manual changes to this file may cause unexpected behavior in your application.
//     Manual changes to this file will be overwritten if the code is regenerated.
//
//------------------------------------------------------------------------------
var styling_context_1 = require("@smartface/styling-context");
var page_1 = __importDefault(require("@smartface/native/ui/page"));
var button_1 = __importDefault(require("@smartface/native/ui/button"));
var flexlayout_1 = __importDefault(require("@smartface/native/ui/flexlayout"));
var label_1 = __importDefault(require("@smartface/native/ui/label"));
var $Page2 = /** @class */ (function (_super) {
    __extends($Page2, _super);
    function $Page2(props) {
        var _this = _super.call(this, Object.assign({ orientation: page_1.default.Orientation.PORTRAIT }, props)) || this;
        _this._children = {};
        _this.ios && (_this.ios.safeAreaLayoutMode = true);
        _this._children.statusBar = _this.statusBar || {};
        _this._children.headerBar = _this.headerBar || {};
        _this.addChildByName(new $BtnLanguage(), 'btnLanguage');
        _this.addChildByName(new $FlexLayout1(), 'flexLayout1');
        _this.addChildByName(new $BtnSayHello(), 'btnSayHello');
        _this.addChildByName(new $BtnOpenModal(), 'btnOpenModal');
        _this.btnLanguage = _this.children.btnLanguage;
        _this.flexLayout1 = _this.children.flexLayout1;
        _this.lbl = _this.children.flexLayout1.children.lbl;
        _this.btnSayHello = _this.children.btnSayHello;
        _this.btnOpenModal = _this.children.btnOpenModal;
        _this.applyTestIDs('_Page2');
        return _this;
    }
    Object.defineProperty($Page2.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    $Page2.prototype.getName = function () {
        return 'Page2';
    };
    $Page2.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.title = 'Second Page';
    };
    $Page2.prototype.addChild = function (child, name, classNames, userProps, defaultClassNames) {
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        if (name) {
            this.addStyleableChild(child, name, classNames, userProps, defaultClassNames);
        }
    };
    /**
     * @deprecated The method should not be used
     */
    $Page2.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        this.addStyleableChild(child, name);
        this.addChild(child);
    };
    $Page2.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $Page2.prototype.removeChild = function (child) {
        var _this = this;
        _super.prototype.removeChild.call(this, child);
        Object.keys(this._children).forEach(function (name) {
            if (child === _this._children[name])
                delete _this._children[name];
        });
    };
    $Page2.prototype.removeChildren = function () {
        this._children = { statusBar: this._children.statusBar, headerBar: this._children.headerBar };
        _super.prototype.removeChildren.call(this);
    };
    $Page2.$$styleContext = {
        classNames: '.sf-page #page2',
        defaultClassNames: ' .default_page',
        userProps: {},
        statusBar: {
            classNames: '.sf-statusBar',
            defaultClassNames: ' .default_statusBar',
            userProps: {}
        },
        headerBar: {
            classNames: '.sf-headerBar',
            defaultClassNames: ' .default_headerBar',
            userProps: {}
        }
    };
    return $Page2;
}((0, styling_context_1.styleablePageMixin)(page_1.default)));
exports.default = $Page2;
var $BtnLanguage = /** @class */ (function (_super) {
    __extends($BtnLanguage, _super);
    function $BtnLanguage(props) {
        return _super.call(this, { text: 'Language Demo' }) || this;
    }
    $BtnLanguage.$$styleContext = {
        classNames: '.sf-button #page2-btnLanguage',
        defaultClassNames: '.default_common .default_button',
        userProps: { usePageVariable: true }
    };
    return $BtnLanguage;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $FlexLayout1 = /** @class */ (function (_super) {
    __extends($FlexLayout1, _super);
    function $FlexLayout1(props) {
        var _this = _super.call(this, props) || this;
        _this._children = {};
        _this.addChildByName(new $FlexLayout1$$Lbl(), 'lbl');
        return _this;
    }
    Object.defineProperty($FlexLayout1.prototype, "children", {
        get: function () {
            return this._children;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * @deprecated The method should not be used
     */
    $FlexLayout1.prototype.addChildByName = function (child, name) {
        this._children[name] = child;
        if (this['layout']) {
            this['layout'].addChild(child);
        }
        else {
            this.addChild(child);
        }
    };
    $FlexLayout1.prototype.applyTestIDs = function (testId) {
        var _this = this;
        Object.keys(this._children).forEach(function (child) {
            _this._children[child].testId = testId + '_' + child.charAt(0).toUpperCase() + child.slice(1);
            if (_this._children[child].applyTestIDs) {
                _this._children[child].applyTestIDs(_this._children[child].testId);
            }
        });
    };
    $FlexLayout1.$$styleContext = {
        classNames: '.sf-flexLayout #page1-wrapper',
        defaultClassNames: '.default_common .default_flexLayout',
        userProps: {}
    };
    return $FlexLayout1;
}((0, styling_context_1.styleableContainerComponentMixin)(flexlayout_1.default)));
var $FlexLayout1$$Lbl = /** @class */ (function (_super) {
    __extends($FlexLayout1$$Lbl, _super);
    function $FlexLayout1$$Lbl(props) {
        return _super.call(this, { text: 'Page2' }) || this;
    }
    $FlexLayout1$$Lbl.$$styleContext = {
        classNames: '.sf-label #page1-lbl',
        defaultClassNames: '.default_common .default_label',
        userProps: { usePageVariable: true }
    };
    return $FlexLayout1$$Lbl;
}((0, styling_context_1.styleableComponentMixin)(label_1.default)));
var $BtnSayHello = /** @class */ (function (_super) {
    __extends($BtnSayHello, _super);
    function $BtnSayHello(props) {
        return _super.call(this, { text: 'Say Hello' }) || this;
    }
    $BtnSayHello.$$styleContext = {
        classNames: '.sf-button #page2-btnSayHello',
        defaultClassNames: '.default_common .default_button',
        userProps: { marginBottom: 10, usePageVariable: true }
    };
    return $BtnSayHello;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
var $BtnOpenModal = /** @class */ (function (_super) {
    __extends($BtnOpenModal, _super);
    function $BtnOpenModal(props) {
        return _super.call(this, { text: 'Open a Modal Page' }) || this;
    }
    $BtnOpenModal.$$styleContext = {
        classNames: '.sf-button #page2-btnOpenModal',
        defaultClassNames: '.default_common .default_button',
        userProps: { usePageVariable: true }
    };
    return $BtnOpenModal;
}((0, styling_context_1.styleableComponentMixin)(button_1.default)));
//# sourceMappingURL=index.js.map
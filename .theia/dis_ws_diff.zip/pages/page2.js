"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var page2_1 = __importDefault(require("generated/pages/page2"));
var headerbaritem_1 = __importDefault(require("@smartface/native/ui/headerbaritem"));
var mixins_1 = require("@smartface/mixins");
var color_1 = __importDefault(require("@smartface/native/ui/color"));
var i18n_1 = require("@smartface/i18n");
var Page2 = /** @class */ (function (_super) {
    __extends(Page2, _super);
    function Page2(router, route) {
        var _this = _super.call(this, {}) || this;
        _this.router = router;
        _this.route = route;
        _this.btnSayHello.text = i18n_1.i18n.instance.t('sayHello');
        _this.btnOpenModal.text = i18n_1.i18n.instance.t('openModal');
        _this.btnLanguage.text = i18n_1.i18n.instance.t('printLanguageExample');
        _this.btnSayHello.on('press', function () { return alert(i18n_1.i18n.instance.t('helloWorld')); });
        _this.btnOpenModal.on('press', function () { return _this.router.push('page3'); });
        _this.btnLanguage.on('press', function () { return _this.languageTest(); });
        return _this;
    }
    Page2.prototype.languageTest = function () {
        console.log({
            helloWorld: i18n_1.i18n.instance.t('helloWorld'),
            welcomeUser: i18n_1.i18n.instance.t('welcomeUser', { user: 'Smartface' }),
            keyWithCount0: i18n_1.i18n.instance.t('keyWithCount', { count: 0 }),
            keyWithCount1: i18n_1.i18n.instance.t('keyWithCount', { count: 1 }),
            keyWithCount5: i18n_1.i18n.instance.t('keyWithCount', { count: 5 })
        });
    };
    /**
     * @event onShow
     * This event is called when a page appears on the screen (everytime).
     */
    Page2.prototype.onShow = function () {
        _super.prototype.onShow.call(this);
        this.headerBar.leftItemEnabled = false;
        this.initBackButton(this.router);
        this.routeData && console.info(this.routeData.message);
    };
    /**
     * @event onLoad
     * This event is called once when page is created.
     */
    Page2.prototype.onLoad = function () {
        _super.prototype.onLoad.call(this);
        this.headerBar.setItems([
            new headerbaritem_1.default({
                title: i18n_1.i18n.instance.t('option'),
                color: color_1.default.WHITE,
                onPress: function () {
                    console.log(i18n_1.i18n.instance.t('optionPressed'));
                }
            })
        ]);
    };
    return Page2;
}((0, mixins_1.withDismissAndBackButton)(page2_1.default)));
exports.default = Page2;
//# sourceMappingURL=page2.js.map